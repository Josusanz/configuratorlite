=== WP Configurator Lite ===
Contributors: wpconfigurator
Tags: e-commerce, store, sales, sell, woo, shop, product, get a quote, contact form
Requires at least: 5.6
Tested up to: 6.0
Requires PHP: 7.4
Stable tag: 3.4

WP Configurator Lite is the world’s most popular configurable product solution.

== Description ==

Offer visitors a truly different shopping experience and convert them to customers. Configurator Plugin is the perfect opportunity to make your web store stand out! Simply activate and demonstrate the era of hyperpersonalization!

== Frequently Asked Questions ==

= Will WP Configurator Lite work with my theme? =

Yes! WP Configurator Lite will work with any theme but may require some additional styling.

== Installation ==

= Minimum Requirements =

* PHP 7.4 or greater is recommended
* MySQL 5.6 or greater is recommended

= Installation =

Manual installation method requires downloading the WP Configurator plugin and uploading it to your web server via your favorite FTP application. The WordPress codex contains [instructions on how to do this here](https://wordpress.org/support/article/managing-plugins/#manual-plugin-installation).
