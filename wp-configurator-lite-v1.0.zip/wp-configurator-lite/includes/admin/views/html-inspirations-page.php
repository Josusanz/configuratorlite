<div class="wpcl-pro-box-container">
    <h3><?php esc_html_e( 'Add Inspirations', 'wp-configurator-lite' ); ?></h3>
    <p><?php esc_html_e( 'Don\'t you think some pre defined configurations which helps user a little? then build some.', 'wp-configurator-lite' ); ?></p>
    <a href="https://my.wpconfigurator.com/downloads/configurator-plugin/" class="wpcl-pro-btn">Get Pro!</a>
</div>